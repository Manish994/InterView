﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dependency_Injection1.Fixed_Fully_Dependent
{
    public class Student
    {
        IDBConnection connection;
        public Student(IDBConnection dbonnection)
        {
            connection = dbonnection;
        }

        public void Delete()
        {
            connection.SaveDetails();
        }

        public void Update()
        {
            connection.SaveDetails();
        }

        public void Save()
        {
            connection.SaveDetails();
        }

        public void Crud()
        {
            connection.SaveDetails();
        }

    }
}
