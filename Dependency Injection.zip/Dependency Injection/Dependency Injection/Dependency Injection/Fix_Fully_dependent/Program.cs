﻿using Dependency_Injection.Fix_Fully_dependent;

IDBConnection connection = new OracleDBConnection();
Employeer employeer = new Employeer(connection);
connection.SaveEmpoyeer();
Console.ReadLine();