﻿namespace Dependency_Injection_API.Repository
{
    public class StudentRepository : IStudentRepository
    {
        public string GetNameDetails()
        {
            try
            {
                var name = "Manish_Pokhrel";
                return name;
            }
            catch(Exception)
            {
                throw;
            }
        }
    }
}
