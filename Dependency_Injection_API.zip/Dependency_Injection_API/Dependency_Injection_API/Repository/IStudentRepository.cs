﻿namespace Dependency_Injection_API.Repository
{
    public interface IStudentRepository
    {
        string GetNameDetails();
    }
}
