﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dependency_Injection1.Fully_Dependent
{
    public class OracleDBConnection
    {
        public void SaveStudent()
        {
            Console.WriteLine("Oracle Is Running...");
        }
    }
}
