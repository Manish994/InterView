﻿namespace Dependency_Injection_Core1.Repository
{
    public class Scope : ISingleton, IScoped, ITransient
    {
        int number;
        public Scope()
        {
            number = 0;
        }

        public int GetData()
        {
            return number++;
        }
    }
}
