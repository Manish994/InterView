﻿using Dependency_Injection_Core1.Models;
using Dependency_Injection_Core1.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Dependency_Injection_Core1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ISingleton _singleton;
        private readonly IScoped _scoped;
        private readonly ITransient _transient;
        private readonly ISingleton _secondSingleton;
        private readonly IScoped _secondScoped;
        private readonly ITransient _secondTransient;

        public HomeController(ILogger<HomeController> logger, ISingleton singleton, IScoped scoped,
            ITransient transient, ISingleton secondSingleton, IScoped secondScoped, ITransient secondTransient)
        {
            _logger = logger;
            _singleton = singleton;
            _scoped = scoped;
            _transient = transient;
            _secondSingleton = secondSingleton;
            _secondScoped = secondScoped;
            _secondTransient = secondTransient;
        }

        public IActionResult Index()
        {
            // first get number from interface instancitated object
            // when class is instancitaed, the constructor automatically executed 
            // then dependency injection inject interface instanciated class objects to the conroller dependencies
            // and these dependencies are manually assign to the private filds
            // here action method interacts with the private fields and get related data
            // finally assign to the viewbag

            ViewBag.singleton =  _singleton.GetData();
            ViewBag.scoped = _scoped.GetData();
            ViewBag.transient = _transient.GetData();

            ViewBag.secondSingleton = _secondSingleton.GetData();
            ViewBag.secondScoped = _secondScoped.GetData();
            ViewBag.secondTransient = _secondTransient.GetData();
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
