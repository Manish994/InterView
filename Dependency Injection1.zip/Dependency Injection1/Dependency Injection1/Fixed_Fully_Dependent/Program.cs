﻿using Dependency_Injection1.Fixed_Fully_Dependent;

//IDBConnection connection = new OracleConnection();
IDBConnection connection = new MSSQLConnection();
Student student = new Student(connection);
student.Delete();
student.Update();
student.Save();
student.Crud();
Console.ReadLine();

