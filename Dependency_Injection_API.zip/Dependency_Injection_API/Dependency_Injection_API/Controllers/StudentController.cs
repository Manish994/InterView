﻿using Dependency_Injection_API.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Dependency_Injection_API.Controllers
{
    [ApiController]
    [Route("api/student")]
    public class StudentController : ControllerBase
    {
        private readonly IStudentRepository _studentRepository;
        public StudentController(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }

        [Route("FetchName")]
        [HttpGet]
        public string GetStudentName()
        {
           return _studentRepository.GetNameDetails();
        }
    }
}
