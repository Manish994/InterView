﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dependency_Injection.Fully_Dependent
{
    public class OracleDBConnection
    {
        public void Save()
        {
            Console.WriteLine("Oracle Save method is running...");
        }
    }
}
