﻿namespace Dependency_Injection_API.Repository
{
    public class StaffRepository : IStudentRepository
    {
        public string GetNameDetails()
        {
            try
            {
                return "Kishor Daju";
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
