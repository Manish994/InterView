﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dependency_Injection.Fully_Dependent
{
    public class Employeer
    {
        #region MS-SQL
        // Here Emplyeer data is passing to MS-SqlDbconnection class
        // Then MS-SqlDbconnection class sent to Database

        // for this i have create object of MSSqlDBConnection class
        // and then call save method of MSSqlDBConnection

        // Here if MSSqlDBConnection class is removed permanently
        // then i got error here on Employeer class

        // if this scenerio came then necessary to create antoher class
        // and then also create object of newly created class
        // then only error will be fixed

        #endregion

        #region Oracle
        // Here if want to pass Employeer data to OracleDBConnection class 
        // then create object of Oracle class instead of MSSqlDBConnection class

        //And remaining process is same for all
        #endregion

        #region
        // To resolve this issues, have to create interface class
        // (resolve MSSqlDBConnection/OracleDBConnection fully dependent by Employeer Class)
        #endregion
        MSSqlDBConnection connection = new MSSqlDBConnection();
        public void SaveDetails()
        {
            connection.Save();
        }
    }
}
