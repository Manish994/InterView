﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dependency_Injection1.Fully_Dependent
{
    // tight coupling
    // Student_Class pass data to MSSQLConnection_Class/OracleConnection_Class
    // MSSQLConnection_Class/OracleConnection_Class pass data to database(Ms/Ora)
    // So create object of MSSQLConnection_Class/OracleConnection_Class here
    // if MSSQLConnection_Class/OracleConnection_Class is removed then multiple methods should be changed
    public class Student
    {
        MSSQLConnection connection = new MSSQLConnection();

        public void Save()
        {
            connection.SaveStudent();
        }
        public void Update()
        {
            connection.SaveStudent();
        }

        public void Delete()
        {
            connection.SaveStudent();
        }

        public void Rename()
        {
            connection.SaveStudent();
        }

    }
}
