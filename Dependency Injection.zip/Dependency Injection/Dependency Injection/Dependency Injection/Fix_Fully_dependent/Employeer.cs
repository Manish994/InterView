﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dependency_Injection.Fix_Fully_dependent
{
    public class Employeer
    {
        #region
        // Constructor automatically when object of class is created.
        // dbConnection parameter passes into the local variable connection.
        #endregion
        IDBConnection connection;
        public Employeer(IDBConnection dbConnection)
        {
            connection = dbConnection;
        }
        public void SaveDetails()
        {
            connection.SaveEmpoyeer();
        }
    }
}
