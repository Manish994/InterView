﻿namespace Dependency_Injection_API.Repository
{
    public class TeacherRepository : IStudentRepository
    {
        public string GetNameDetails()
        {
            return "Pushpa Kamal Dahal";
        }
    }
}
