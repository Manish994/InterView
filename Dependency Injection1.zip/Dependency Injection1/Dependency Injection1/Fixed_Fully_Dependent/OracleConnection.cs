﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dependency_Injection1.Fixed_Fully_Dependent
{
    public class OracleConnection : IDBConnection
    { 
        public void SaveDetails()
        {
            Console.WriteLine("Oracle Is Running");
        }
    }
}
