﻿namespace Dependency_Injection_Core1.Repository
{
    public interface ISingleton
    {
        int GetData();
    }

    public interface IScoped
    {
        int GetData();
    }

    public interface ITransient
    {
        int GetData();
    }
}
