﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dependency_Injection.Fix_Fully_dependent
{
    public interface IDBConnection
    {
        void SaveEmpoyeer();
    }
}
